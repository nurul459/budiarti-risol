<?php
session_start();

if (!isset($_SESSION['id_user'])) {
    header("Location: ../user/login.php");
    exit;
}

if ($_SESSION['role'] !== 'admin') {
    echo "Akses ditolak. Halaman ini hanya untuk admin.";
    exit;
}
?>